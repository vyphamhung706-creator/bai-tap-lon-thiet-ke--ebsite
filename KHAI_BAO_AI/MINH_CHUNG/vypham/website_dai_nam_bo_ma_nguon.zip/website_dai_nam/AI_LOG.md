# AI_LOG – NHẬT KÝ SỬ DỤNG AI

## 1. Công cụ
- ChatGPT.
- GitHub Copilot trong Visual Studio Code (nếu thực tế có sử dụng).

## 2. Mục đích
AI được dùng để tham khảo cấu trúc HTML/CSS, gợi ý cải thiện khả năng truy cập, responsive và hỗ trợ rà soát tài liệu. Người thực hiện cần tự kiểm tra và chịu trách nhiệm với mã nguồn cuối cùng.

## 3. Nội dung AI hỗ trợ
| STT | Nội dung yêu cầu | Phần được tham khảo |
|---|---|---|
| 1 | Gợi ý cấu trúc website | Header, banner, giới thiệu, ngành học, hình ảnh, liên hệ, footer |
| 2 | Gợi ý HTML ngữ nghĩa | Header, nav, main, section, article, footer |
| 3 | Gợi ý CSS | Flexbox, Grid, màu sắc, khoảng cách |
| 4 | Gợi ý responsive | Media Query cho tablet và điện thoại |
| 5 | Gợi ý accessibility | Alt ảnh, label, skip link, focus-visible |
| 6 | Gợi ý tài liệu | README và CHANGELOG |

## 4. Nhật ký kiểm tra và xử lý
| Mã | Điểm cần kiểm tra | Cách xử lý trong phiên bản này | Trạng thái kiểm tra |
|---|---|---|---|
| A11Y-01 | Thiếu liên kết bỏ qua menu | Bổ sung skip-link | Cần kiểm tra bằng bàn phím |
| A11Y-02 | Thiếu nhãn trường nhập | Bổ sung label và liên kết for/id | Cần kiểm tra |
| A11Y-03 | Khó nhận biết focus | Bổ sung focus-visible | Cần kiểm tra |
| RWD-01 | Banner có thể chật ở màn hình trung bình | Chuyển banner thành một cột ở màn hình nhỏ hơn 700px | Cần thử nhiều kích thước |
| FORM-01 | Form chưa gửi dữ liệu | Ghi rõ form chỉ minh họa, nút gửi bị vô hiệu hóa | Đã thể hiện trong giao diện |
| DOC-01 | Tên CHANGELOG chưa thống nhất | Chuẩn hóa tên tài liệu | Cần kiểm tra tên file thực tế |

## 5. Phần việc cá nhân
Người thực hiện lựa chọn đề tài, chuẩn bị hình ảnh, chỉnh sửa nội dung, sắp xếp tệp, chạy thử website và quyết định nội dung cuối cùng được sử dụng.

## 6. Đánh giá
Các gợi ý của AI chỉ là tài liệu tham khảo. Cần chạy website trên trình duyệt, kiểm tra đường dẫn ảnh, liên kết, responsive và khả năng điều hướng bằng bàn phím trước khi kết luận lỗi đã được khắc phục.

## 7. Cam kết
Người thực hiện chịu trách nhiệm về sản phẩm cuối cùng và cần khai báo đúng công cụ AI thực tế đã sử dụng. Không ghi nhận một lỗi là đã sửa nếu chưa kiểm tra lại.
