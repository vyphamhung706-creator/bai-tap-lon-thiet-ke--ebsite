# WEBSITE GIỚI THIỆU ĐẠI HỌC ĐẠI NAM

## 1. Giới thiệu
Dự án xây dựng website tĩnh giới thiệu Trường Đại học Đại Nam, trình bày thông tin tổng quan, một số ngành học, hình ảnh và liên kết liên hệ.

## 2. Đối tượng người xem
- Học sinh đang tìm hiểu trường đại học.
- Phụ huynh và người quan tâm đến nhà trường.
- Sinh viên muốn xem thông tin giới thiệu cơ bản.

## 3. Mục tiêu
- Trình bày thông tin theo bố cục rõ ràng.
- Giúp người xem di chuyển nhanh giữa các phần.
- Hiển thị phù hợp trên máy tính và điện thoại.
- Thực hành HTML5 và CSS3.

## 4. Công nghệ
- HTML5: cấu trúc và nội dung.
- CSS3: màu sắc, bố cục, hiệu ứng và responsive.
- Không sử dụng JavaScript hoặc backend.

## 5. Nội dung website
1. Trang chủ và banner.
2. Giới thiệu.
3. Một số ngành học tiêu biểu.
4. Thư viện hình ảnh.
5. Thông tin liên hệ và biểu mẫu minh họa.
6. Chân trang.

## 6. Cấu trúc thư mục
```text
bai tap lon thiet ke website/
├── index.html
├── style.css
├── Logo-DH-Dai-Nam-.webp
├── anh chinh.jpg
├── anh2.webp
├── anh3.jpg
├── anh4.jpg
├── anh5.jpg
├── README.md
├── AI_LOG.md
└── CHANGELOG.md
```

## 7. Cách chạy
1. Giữ nguyên các tệp ảnh trong cùng thư mục với `index.html`.
2. Mở thư mục dự án bằng Visual Studio Code.
3. Mở `index.html` bằng trình duyệt hoặc dùng tiện ích Live Server.
4. Không cần cài máy chủ hoặc cơ sở dữ liệu.

## 8. Tiêu chí tự kiểm tra
- Các phần nội dung xuất hiện đầy đủ.
- Logo và hình ảnh tải đúng.
- Menu chuyển đến đúng khu vực.
- Không có thanh cuộn ngang ở kích thước điện thoại thông dụng.
- Có thể dùng phím Tab để di chuyển và nhìn thấy viền focus.
- Liên kết website chính thức mở được.

## 9. Giới hạn
Đây là website tĩnh. Biểu mẫu chỉ minh họa giao diện, không gửi hoặc lưu dữ liệu. Thông tin ngành học và nội dung giới thiệu cần được đối chiếu với nguồn chính thức trước khi nộp.

## 10. Tác giả
Sinh viên thực hiện: Phạm Hùng Vỹ  
Đề tài: Website giới thiệu Trường Đại học Đại Nam.
